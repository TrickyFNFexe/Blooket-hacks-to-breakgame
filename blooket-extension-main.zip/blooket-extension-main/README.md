# Blooket Extension
Blooket extension based off: https://github.com/glixzzy/blooket-hack along with more cheats

## How to Install

1. Download repo as ZIP ![image](https://user-images.githubusercontent.com/49218878/137042579-0f79cf75-e5e9-4bac-8e84-03d025517f63.png)
2. Go to `chrome://extensions` and enable developer mode if its not already on ![image](https://user-images.githubusercontent.com/49218878/137042614-44fe0625-f39d-4772-bafc-9d582f8f916a.png)
3. Click 'Load Unpacked' ![image](https://user-images.githubusercontent.com/49218878/137042636-d9ac1db3-9d44-4851-a793-fed0980f03bd.png)
4. Navigate to the extracted ZIP folder and select folder ![image](https://user-images.githubusercontent.com/49218878/137043106-321800e7-12b5-4fd1-b47d-a673325212f5.png)
5. Click on Extension icon to use ![image](https://user-images.githubusercontent.com/49218878/137043399-2564312f-1125-4285-bf74-25de172fff69.png)
